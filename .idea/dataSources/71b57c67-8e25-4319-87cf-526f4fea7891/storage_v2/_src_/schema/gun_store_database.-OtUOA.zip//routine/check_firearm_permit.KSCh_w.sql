create
    definer = root@localhost procedure check_firearm_permit(IN person_id int, OUT has_permit tinyint(1))
BEGIN
    DECLARE buyer_permit_id INT;
    DECLARE permit_expiration_date DATE;
    DECLARE EXIT HANDLER FOR NOT FOUND SET has_permit = FALSE;
    SET has_permit = FALSE;
    SELECT firearm_permit_id FROM buyer WHERE buyer.person_id = person_id INTO buyer_permit_id;
    IF buyer_permit_id IS NOT NULL THEN
        SELECT expiration_date FROM firearm_permit WHERE firearm_permit.id = buyer_permit_id INTO permit_expiration_date;
        IF permit_expiration_date > CURDATE() THEN
            SET has_permit = TRUE;
        END IF;
    END IF;
END;

