create view rifles_in_stock as
select `gun_store_database`.`items_in_stock`.`id`           AS `id`,
       `gun_store_database`.`items_in_stock`.`manufacturer` AS `manufacturer`,
       `gun_store_database`.`items_in_stock`.`model`        AS `model`,
       `gun_store_database`.`items_in_stock`.`price`        AS `price`,
       `gun_store_database`.`items_in_stock`.`in_stock`     AS `in_stock`,
       `gun_store_database`.`rifle`.`item_id`               AS `item_id`,
       `gun_store_database`.`rifle`.`caliber`               AS `caliber`,
       `gun_store_database`.`rifle`.`magazine_capacity`     AS `magazine_capacity`
from (`gun_store_database`.`items_in_stock`
         join `gun_store_database`.`rifle`
              on ((`gun_store_database`.`items_in_stock`.`id` = `gun_store_database`.`rifle`.`item_id`)));

