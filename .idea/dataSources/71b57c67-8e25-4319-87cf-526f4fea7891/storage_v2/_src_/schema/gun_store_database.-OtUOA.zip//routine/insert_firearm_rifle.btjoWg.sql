create
    definer = root@localhost procedure insert_firearm_rifle(IN rifle_manufacturer varchar(45),
                                                            IN rifle_model varchar(45), IN rifle_price double,
                                                            IN in_stock int, IN rifle_caliber varchar(45),
                                                            IN rifle_magazine int)
BEGIN
	START TRANSACTION;
		INSERT INTO Item VALUE (0, rifle_manufacturer, rifle_model, rifle_price, in_stock);
        INSERT INTO Rifle VALUE(Item.last_insert_id(), rifle_caliber, rifle_magazine);
        INSERT INTO Firearm_Rifle VALUE(Rifle.last_insert_id());
    COMMIT WORK;
END;

