create view employee_details as
select `gun_store_database`.`person`.`id`                  AS `id`,
       `gun_store_database`.`person`.`first_name`          AS `first_name`,
       `gun_store_database`.`person`.`last_name`           AS `last_name`,
       `gun_store_database`.`phone_number`.`phone_number`  AS `phone_number`,
       concat_ws(', ', `gun_store_database`.`address`.`city`, `gun_store_database`.`address`.`street`,
                 `gun_store_database`.`address`.`number`)  AS `address`,
       `gun_store_database`.`employee`.`employee_username` AS `employee_username`,
       `gun_store_database`.`employee`.`employee_password` AS `employee_password`
from (((`gun_store_database`.`person` join `gun_store_database`.`employee` on ((`gun_store_database`.`person`.`id` =
                                                                                `gun_store_database`.`employee`.`person_id`))) join `gun_store_database`.`address` on ((
        `gun_store_database`.`employee`.`address_id` = `gun_store_database`.`address`.`id`)))
         join `gun_store_database`.`phone_number`
              on ((`gun_store_database`.`phone_number`.`person_id` = `gun_store_database`.`employee`.`person_id`)));

