create
    definer = root@localhost procedure requires_permit(IN selected_item_id int, OUT requires_permit tinyint(1))
BEGIN
    SET requires_permit = FALSE;
    IF selected_item_id IN (SELECT item_id FROM munition) OR selected_item_id IN (SELECT item_id FROM firearm_rifle) OR selected_item_id IN (SELECT item_id FROM firearm_pistol) THEN
        SET requires_permit = TRUE;
    END IF;
END;

