create definer = root@localhost trigger phone_number_integrity
    before update
    on phone_number
    for each row
BEGIN
	IF NOT isnull(new.Person_id) AND NOT isnull(new.Supplier_id) THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You can not insert record';
	ELSEIF isnull(new.Person_id) AND isnull(new.Supplier_id) THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You can not insert record';
	END IF;
END;

