create definer = root@localhost trigger update_total_price
    after insert
    on receipt_has_item
    for each row
BEGIN
	UPDATE Reciept SET Receipt.total_price = Receipt.total_price + (NEW.ammount * NEW.item_price) WHERE Receipt.id = NEW.receipt_id;
END;

