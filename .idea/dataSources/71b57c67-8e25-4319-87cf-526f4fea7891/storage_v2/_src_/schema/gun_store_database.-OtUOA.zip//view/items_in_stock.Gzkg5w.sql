create definer = root@localhost view items_in_stock as
select `gun_store_database`.`item`.`id`           AS `id`,
       `gun_store_database`.`item`.`manufacturer` AS `manufacturer`,
       `gun_store_database`.`item`.`model`        AS `model`,
       `gun_store_database`.`item`.`price`        AS `price`,
       `gun_store_database`.`item`.`in_stock`     AS `in_stock`
from `gun_store_database`.`item`
where (`gun_store_database`.`item`.`in_stock` <> 0);

