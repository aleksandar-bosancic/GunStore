create
    definer = root@localhost procedure login_procedure(IN username varchar(45), IN user_password varchar(45),
                                                       OUT is_valid tinyint(1))
BEGIN
    DECLARE employee_username VARCHAR(45);
    DECLARE employee_password VARCHAR(45);
	DECLARE login_cursor CURSOR FOR SELECT emp.employee_username, emp.employee_password FROM Employee emp WHERE emp.employee_username = username AND emp.employee_password = user_password;
    DECLARE EXIT HANDLER FOR NOT FOUND SET is_valid = FALSE;
	SET is_valid = FALSE;
    OPEN login_cursor;
    FETCH login_cursor INTO employee_username, employee_password;
    SELECT employee_username, employee_password;
    SET is_valid = TRUE;
END;

