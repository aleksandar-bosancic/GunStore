create
    definer = root@localhost procedure login_procedure(IN username varchar(45), IN user_password varchar(45),
                                                       OUT is_valid tinyint(1))
BEGIN
	DECLARE login_cursor CURSOR FOR SELECT * FROM Employee emp WHERE emp.employee_username = username AND emp.employee_password = user_password;
    DECLARE EXIT HANDLER FOR NOT FOUND SET is_valid = FALSE;
    OPEN login_cursor;
    SET is_valid = TRUE;
END;

